"""Recursive-descent parser for the Noisemaker Polymorphic DSL.

Faithful Python port of the reference parser (shaders/src/lang/parser.js). Consumes the
token list produced by the stage-1 lexer (``noisemaker_blender.compiler.lexer.lex``) and
produces an AST whose node shapes are byte-for-byte equivalent to the reference's ``parse()``
output (verified structurally against golden ASTs over the parity corpus).

Pure stdlib, fully self-contained: this runs inside Blender's bundled Python, so there are no
third-party imports and no dependency on the reference repo. The two symbols the reference
parser imports from ``runtime/tags.js`` (``isValidNamespace`` / ``VALID_NAMESPACES``) are
inlined below as the static set of built-in namespace IDs — the parser never registers or
unregisters namespaces at runtime, so a frozen list reproduces its behavior exactly.

Grammar (EBNF), mirroring the reference:

    Program        ::= SearchDirective? Statement* RenderDirective?
    SearchDirective::= 'search' Ident (',' Ident)*
    Statement      ::= VarAssign | ChainStmt | IfStmt | Break | Continue | Return
    RenderDirective::= 'render' '(' OutputRef ')'
    Block          ::= '{' Statement* '}'
    IfStmt         ::= 'if' '(' Expr ')' Block ('elif' '(' Expr ')' Block)* ('else' Block)?
    Break          ::= 'break'
    Continue       ::= 'continue'
    Return         ::= 'return' Expr?
    VarAssign      ::= 'let' Ident '=' Expr
    ChainStmt      ::= Chain
    Chain          ::= ChainElement ('.' ChainElement)*
    ChainElement   ::= Call | WriteNode | Write3DNode
    Expr           ::= Chain | NumberExpr | String | Boolean | Color | Ident | Member
                       | OutputRef | SourceRef | Func | '(' Expr ')'
    Call           ::= Ident '(' ArgList? ')'
    NumberExpr     ::= Number | 'Math.PI' | '(' NumberExpr ')'
                       | NumberExpr ( '+' | '-' | '*' | '/' ) NumberExpr

The AST node contract (what later compiler stages can rely on) is documented inline at each
production. ``parse(tokens)`` is the primary entry point; ``parse_source(src)`` lexes then parses.
"""

import math

from .lang_data import DIAGNOSTICS
from .lexer import lex


class SyntaxError_(SyntaxError):
    """Raised on malformed source (mirrors the reference's thrown ``SyntaxError``).

    Named with a trailing underscore so it does not shadow the builtin ``SyntaxError`` at the
    use sites below, while still subclassing it so ``except SyntaxError`` also catches it.
    """

    diagnostic: dict | None = None


# Built-in namespace IDs accepted by the `search` directive. Mirrors the seed set in
# runtime/tags.js (_builtinDescriptors). The reference's isValidNamespace() also accepts
# namespaces registered at runtime via registerNamespace(), but the parser stage never
# registers any, so this static frozenset reproduces parse-time validation exactly.
VALID_NAMESPACES = (
    "io",
    "classicNoisedeck",
    "synth",
    "mixer",
    "filter",
    "render",
    "points",
    "synth3d",
    "filter3d",
    "user",
)
_VALID_NAMESPACES_SET = frozenset(VALID_NAMESPACES)


def _is_valid_namespace(namespace_id):
    return namespace_id in _VALID_NAMESPACES_SET


def _make_number(value):
    """Produce a Number node value matching JS numeric semantics.

    JS has a single Number type; ``JSON.stringify`` of an integral float (e.g. ``30.0``)
    emits ``30``. We mirror that by storing integral values as Python ``int`` so the
    serialized/structural form matches the golden, while retaining negative zero and
    non-integral values as ``float`` for subsequent arithmetic.
    """
    if (
        isinstance(value, float)
        and value.is_integer()
        and math.isfinite(value)
        and not (value == 0 and math.copysign(1, value) < 0)
    ):
        return int(value)
    return value


def _parse_js_number(lexeme):
    """Parse a numeric lexeme the way JS ``parseFloat`` would, returning int-or-float."""
    return _make_number(float(lexeme))


def _to_js_number(value):
    """Coerce a Python numeric value back to JavaScript's binary64 Number domain."""
    try:
        return float(value)
    except OverflowError:
        return -math.inf if value < 0 else math.inf


def _js_binary_number(left, right, operator):
    """Evaluate parser arithmetic with JavaScript Number semantics."""
    left = _to_js_number(left)
    right = _to_js_number(right)
    if operator == "PLUS":
        result = left + right
    elif operator == "MINUS":
        result = left - right
    elif operator == "STAR":
        result = left * right
    elif right != 0:
        result = left / right
    elif left == 0 or math.isnan(left):
        result = math.nan
    else:
        negative = math.copysign(1, left) != math.copysign(1, right)
        result = -math.inf if negative else math.inf
    return _make_number(result)


class AstNode(dict):
    """AST node dict subclass carrying non-enumerable compiler metadata."""
    position: dict | None = None
    subchainArgumentDiagnostics: list | None = None


def parse(tokens, options=None):
    """Parse a token stream into an AST.

    :param tokens: token list from :func:`noisemaker_blender.compiler.lexer.lex`
    :param options: optional dict of parser options (e.g. {"subchainArguments": "strict"})
    :returns: the Program AST (a nested dict / list structure)
    :raises SyntaxError_: on malformed input (same cases as the reference parser)
    """
    state = {"current": 0}

    # Track the search order for the program (set by search directive - REQUIRED).
    program_search_order = {"value": None}

    # Program namespace starts empty - must be set by search directive.
    program_namespace = {"imports": [], "default": None}

    def peek():
        return tokens[state["current"]]

    def advance():
        tok = tokens[state["current"]]
        state["current"] += 1
        return tok

    def tok_at(idx):
        """Bounds-safe token lookup; returns None past the end (mirrors JS ``tokens[i]``)."""
        if 0 <= idx < len(tokens):
            return tokens[idx]
        return None

    def tok_loc(tok):
        line = tok.get("line") if isinstance(tok, dict) else None
        col = tok.get("col") if isinstance(tok, dict) else None
        if col is None and isinstance(tok, dict):
            col = tok.get("column")
        return {"line": line, "col": col}

    def loc_suffix(tok):
        line_str = "undefined" if not isinstance(tok, dict) or tok.get("line") is None else tok["line"]
        col = tok.get("col") if isinstance(tok, dict) else None
        if col is None and isinstance(tok, dict):
            col = tok.get("column")
        col_str = "undefined" if col is None else col
        return f"at line {line_str} col {col_str}"

    def parser_error(code, msg_str, token, severity_override=None):
        error = SyntaxError_(msg_str)
        token_pos = getattr(token, "position", None) or (token.get("position") if isinstance(token, dict) else None)
        has_position = (
            token_pos is not None
            and isinstance(token_pos.get("line"), int) and not isinstance(token_pos.get("line"), bool) and token_pos["line"] > 0
            and isinstance(token_pos.get("column"), int) and not isinstance(token_pos.get("column"), bool) and token_pos["column"] > 0
            and isinstance(token_pos.get("start"), int) and not isinstance(token_pos.get("start"), bool) and token_pos["start"] >= 0
            and isinstance(token_pos.get("end"), int) and not isinstance(token_pos.get("end"), bool) and token_pos["end"] >= token_pos["start"]
        )
        token_line = token.get("line") if isinstance(token, dict) else None
        token_col = token.get("col") if isinstance(token, dict) else None
        if token_col is None and isinstance(token, dict):
            token_col = token.get("column")
        has_location = (
            isinstance(token_line, int)
            and not isinstance(token_line, bool)
            and token_line > 0
            and isinstance(token_col, int)
            and not isinstance(token_col, bool)
            and token_col > 0
        )
        location = (
            {"line": token_pos["line"], "column": token_pos["column"]}
            if has_position
            else ({"line": token_line, "column": token_col} if has_location else None)
        )
        span = {"start": token_pos["start"], "end": token_pos["end"]} if has_position else None
        error.diagnostic = {
            "code": code,
            "stage": DIAGNOSTICS[code]["stage"],
            "severity": severity_override or DIAGNOSTICS[code]["severity"],
            "message": msg_str,
            "location": location,
            "span": span,
        }
        return error

    def expect(type_, msg):
        token = peek()
        if token["type"] == type_:
            return advance()
        msg_str = f"{msg} {loc_suffix(token)}"
        code = "P002" if type_ == "RPAREN" else "P001"
        raise parser_error(code, msg_str, token)

    def collect_comments():
        """Collect and consume any pending COMMENT tokens; return list of lexeme strings."""
        comments = []
        while True:
            t = peek()
            if t is not None and t.get("type") == "COMMENT":
                comments.append(advance()["lexeme"])
            else:
                break
        return comments

    expr_start_tokens = frozenset([
        "PLUS", "MINUS", "NUMBER", "HEX", "FUNC", "STRING",
        "IDENT", "OUTPUT_REF", "SOURCE_REF", "VOL_REF", "GEO_REF", "MESH_REF",
        "XYZ_REF", "VEL_REF", "RGBA_REF", "LPAREN", "LBRACKET",
        "TRUE", "FALSE",
    ])

    member_token_types = frozenset([
        "IDENT", "SOURCE_REF", "OUTPUT_REF", "VOL_REF", "GEO_REF", "MESH_REF",
        "XYZ_REF", "VEL_REF", "RGBA_REF",
        "LET", "RENDER", "TRUE", "FALSE", "IF", "ELIF", "ELSE",
        "BREAK", "CONTINUE", "RETURN", "WRITE", "WRITE3D", "SUBCHAIN",
    ])

    # ---- osc()/midi()/audio()/from() invocation transforms ------------------------------

    def transform_osc_invocation(call, name_token):
        """Transform an osc() call into an Oscillator AST node.

        osc(type, min?, max?, speed?, offset?, seed?) — all params except 'type' optional,
        positional or kwargs.
        """
        args = call["args"] if isinstance(call.get("args"), list) else []
        kwargs = call.get("kwargs") or {}

        param_order = ["type", "min", "max", "speed", "offset", "seed"]
        valid_params = set(param_order)
        defaults = {
            "type": {"type": "Member", "path": ["oscKind", "sine"]},
            "min": {"type": "Number", "value": 0},
            "max": {"type": "Number", "value": 1},
            "speed": {"type": "Number", "value": 1},
            "offset": {"type": "Number", "value": 0},
            "seed": {"type": "Number", "value": 1},
        }

        for key in kwargs.keys():
            if key not in valid_params:
                raise parser_error(
                    "P003",
                    f"osc() unknown parameter '{key}' {loc_suffix(name_token)}. Valid: {', '.join(param_order)}",
                    name_token,
                )

        resolved = {}
        for i, param_name in enumerate(param_order):
            if kwargs.get(param_name) is not None:
                resolved[param_name] = kwargs[param_name]
            elif i < len(args):
                resolved[param_name] = args[i]
            elif defaults.get(param_name) is not None:
                resolved[param_name] = defaults[param_name]

        return {
            "type": "Oscillator",
            "oscType": resolved.get("type"),
            "min": resolved.get("min"),
            "max": resolved.get("max"),
            "speed": resolved.get("speed"),
            "offset": resolved.get("offset"),
            "seed": resolved.get("seed"),
            "loc": tok_loc(name_token),
        }

    def transform_midi_invocation(call, name_token):
        """Transform a midi() call into a Midi AST node.

        midi(channel?, mode?, min?, max?, sensitivity?, name:?, id:?, cc:?,
             nrpn:?, zone:?, members:?) — exactly one of channel or zone.
        """
        args = call["args"] if isinstance(call.get("args"), list) else []
        kwargs = call.get("kwargs") or {}

        param_order = ["channel", "mode", "min", "max", "sensitivity"]
        keyword_only_params = ["name", "id", "cc", "nrpn", "zone", "members"]
        valid_params = param_order + keyword_only_params
        if len(args) > len(param_order):
            raise parser_error(
                "P003",
                f"midi() name, id, cc, nrpn, zone and members are keyword-only {loc_suffix(name_token)}",
                name_token,
            )
        for key in kwargs.keys():
            if key not in valid_params:
                raise parser_error(
                    "P003",
                    f"midi() unknown parameter '{key}' {loc_suffix(name_token)}. Valid: {', '.join(valid_params)}",
                    name_token,
                )
        defaults = {
            "mode": {"type": "Member", "path": ["midiMode", "velocity"]},
            "min": {"type": "Number", "value": 0},
            "max": {"type": "Number", "value": 1},
            "sensitivity": {"type": "Number", "value": 1},
        }

        resolved = {}
        pos_cursor = 0
        for param_name in param_order:
            if kwargs.get(param_name) is not None:
                resolved[param_name] = kwargs[param_name]
            elif pos_cursor < len(args):
                resolved[param_name] = args[pos_cursor]
                pos_cursor += 1
            elif defaults.get(param_name) is not None:
                resolved[param_name] = defaults[param_name]

        if pos_cursor < len(args):
            raise parser_error(
                "P003",
                f"midi() has an excess positional argument {loc_suffix(name_token)}",
                name_token,
            )
        if not resolved.get("channel") and kwargs.get("zone") is None:
            raise parser_error(
                "P003",
                f"midi() requires 'channel' or 'zone' argument {loc_suffix(name_token)}",
                name_token,
            )
        if resolved.get("channel") and kwargs.get("zone") is not None:
            raise parser_error(
                "P003",
                f"midi() 'channel' and 'zone' are mutually exclusive {loc_suffix(name_token)}",
                name_token,
            )
        if kwargs.get("members") is not None and kwargs.get("zone") is None:
            raise parser_error(
                "P003",
                f"midi() 'members' requires 'zone' {loc_suffix(name_token)}",
                name_token,
            )
        if kwargs.get("id") is not None and kwargs.get("name") is None:
            raise parser_error(
                "P003",
                f"midi() 'id' requires readable 'name' {loc_suffix(name_token)}",
                name_token,
            )
        for param_name in ("name", "id"):
            value = kwargs.get(param_name)
            if value is None:
                continue
            if value.get("type") != "String":
                raise parser_error(
                    "P003",
                    f"midi() '{param_name}' requires a quoted string {loc_suffix(name_token)}",
                    name_token,
                )
            if len(value.get("value", "")) == 0:
                raise parser_error(
                    "P003",
                    f"midi() '{param_name}' must not be empty {loc_suffix(name_token)}",
                    name_token,
                )

        node = {
            "type": "Midi",
            "mode": resolved.get("mode"),
            "min": resolved.get("min"),
            "max": resolved.get("max"),
            "sensitivity": resolved.get("sensitivity"),
            "loc": tok_loc(name_token),
        }
        if resolved.get("channel") is not None:
            node["channel"] = resolved["channel"]
        for param_name in keyword_only_params:
            if kwargs.get(param_name) is not None:
                node[param_name] = kwargs[param_name]
        return node

    def transform_audio_invocation(call, name_token):
        """Transform an audio() call into an Audio AST node.

        audio(band, min?, max?, channel:?, name:?, id:?) — band required.
        """
        args = call["args"] if isinstance(call.get("args"), list) else []
        kwargs = call.get("kwargs") or {}

        param_order = ["band", "min", "max"]
        keyword_only_params = ["channel", "name", "id"]
        valid_params = param_order + keyword_only_params
        if len(args) > len(param_order):
            raise parser_error(
                "P003",
                f"audio() channel, name and id are keyword-only {loc_suffix(name_token)}",
                name_token,
            )
        for key in kwargs.keys():
            if key not in valid_params:
                raise parser_error(
                    "P003",
                    f"audio() unknown parameter '{key}' {loc_suffix(name_token)}. Valid: {', '.join(valid_params)}",
                    name_token,
                )
        defaults = {
            "min": {"type": "Number", "value": 0},
            "max": {"type": "Number", "value": 1},
        }

        resolved = {}
        pos_cursor = 0
        for param_name in param_order:
            if kwargs.get(param_name) is not None:
                resolved[param_name] = kwargs[param_name]
            elif pos_cursor < len(args):
                resolved[param_name] = args[pos_cursor]
                pos_cursor += 1
            elif defaults.get(param_name) is not None:
                resolved[param_name] = defaults[param_name]

        if pos_cursor < len(args):
            raise parser_error(
                "P003",
                f"audio() has an excess positional argument {loc_suffix(name_token)}",
                name_token,
            )
        if not resolved.get("band"):
            raise parser_error(
                "P003",
                f"audio() requires 'band' argument {loc_suffix(name_token)}",
                name_token,
            )
        if kwargs.get("id") is not None and kwargs.get("name") is None:
            raise parser_error(
                "P003",
                f"audio() 'id' requires readable 'name' {loc_suffix(name_token)}",
                name_token,
            )
        if kwargs.get("name") is not None and kwargs.get("channel") is None:
            raise parser_error(
                "P003",
                f"audio() selected device requires both 'name' and 'channel' {loc_suffix(name_token)}",
                name_token,
            )
        for param_name in ("name", "id"):
            value = kwargs.get(param_name)
            if value is None:
                continue
            if value.get("type") != "String":
                raise parser_error(
                    "P003",
                    f"audio() '{param_name}' requires a quoted string {loc_suffix(name_token)}",
                    name_token,
                )
            if len(value.get("value", "")) == 0:
                raise parser_error(
                    "P003",
                    f"audio() '{param_name}' must not be empty {loc_suffix(name_token)}",
                    name_token,
                )

        node = {
            "type": "Audio",
            "band": resolved.get("band"),
            "min": resolved.get("min"),
            "max": resolved.get("max"),
            "loc": tok_loc(name_token),
        }
        for param_name in keyword_only_params:
            if kwargs.get(param_name) is not None:
                node[param_name] = kwargs[param_name]
        return node

    def transform_from_invocation(call, name_token):
        def fail(message):
            if (
                name_token is not None
                and isinstance(name_token.get("line"), int)
                and isinstance(name_token.get("col"), int)
            ):
                raise parser_error(
                    "P007",
                    "%s at line %d col %d" % (message, name_token["line"], name_token["col"]),
                    name_token,
                )
            raise parser_error("P007", message, name_token)

        if call.get("kwargs") and len(call["kwargs"]):
            fail("'from' does not support named arguments")
        args = call["args"] if isinstance(call.get("args"), list) else []
        if len(args) != 2:
            fail("'from' requires exactly two arguments (namespace, call)")
        namespace_arg, target_arg = args[0], args[1]
        if not namespace_arg or (
            namespace_arg.get("type") != "Ident" and namespace_arg.get("type") != "Member"
        ):
            fail("'from' namespace argument must be an identifier")
        if namespace_arg.get("type") == "Member":
            namespace_name = ".".join(namespace_arg["path"])
        else:
            namespace_name = namespace_arg.get("name")
        if not namespace_name:
            fail("'from' namespace argument must be non-empty")

        target_call = None
        if target_arg and target_arg.get("type") == "Call":
            target_call = target_arg
        elif (
            target_arg
            and target_arg.get("type") == "Chain"
            and isinstance(target_arg.get("chain"), list)
            and len(target_arg["chain"]) == 1
        ):
            head = target_arg["chain"][0]
            if head and head.get("type") == "Call":
                target_call = head
        if not target_call:
            fail("'from' second argument must be a call expression")

        # Shallow-clone the target call, copying its args list (JS: targetCall.args.map(a => a)).
        replacement = dict(target_call)
        if isinstance(target_call.get("args"), list):
            replacement["args"] = list(target_call["args"])
        else:
            replacement["args"] = []
        if target_call.get("kwargs"):
            replacement["kwargs"] = dict(target_call["kwargs"])

        override_namespace = {
            "name": namespace_name,
            "path": [namespace_name],
            "explicit": True,
            "source": "from",
            "resolved": namespace_name,
            "searchOrder": [namespace_name],
            "fromOverride": True,
        }
        replacement["namespace"] = override_namespace
        return replacement

    def has_call_after_dot(index):
        i = index + 1
        t = tok_at(i)
        if t is None or t.get("type") != "DOT":
            return False
        while True:
            t = tok_at(i)
            if t is None or t.get("type") != "DOT":
                break
            seg_token = tok_at(i + 1)
            if seg_token is None or seg_token.get("type") not in member_token_types:
                return False
            i += 2
        t = tok_at(i)
        return t is not None and t.get("type") == "LPAREN"

    def parse_render_directive():
        advance()
        expect("LPAREN", "Expect '('")
        if peek()["type"] != "OUTPUT_REF":
            raise parser_error("P005", "Expected output reference in render()", peek())
        out = {"type": "OutputRef", "name": advance()["lexeme"]}
        expect("RPAREN", "Expect ')'")
        return out

    def parse_program():
        plans = []
        variables = []
        render = {"value": None}
        trailing_comments = []

        def append_statement(stmt):
            if not stmt or not isinstance(stmt, dict):
                return
            if stmt.get("type") == "VarAssign":
                variables.append(stmt)
            else:
                plans.append(stmt)

        def consume_render():
            if render["value"]:
                t = peek()
                raise parser_error(
                    "P005",
                    f"Duplicate render() directive {loc_suffix(t)}",
                    t,
                )
            render["value"] = parse_render_directive()
            while peek()["type"] == "SEMICOLON":
                advance()

        # Token types that can be used as namespace identifiers (keywords like 'render' are
        # valid namespace names in search context).
        namespace_token_types = frozenset([
            "IDENT", "RENDER", "WRITE", "WRITE3D", "TRUE", "FALSE",
            "IF", "ELIF", "ELSE", "BREAK", "CONTINUE", "RETURN",
        ])

        def parse_search_directive():
            if program_search_order["value"] is not None:
                t = peek()
                raise parser_error(
                    "P004",
                    f"Only one search directive is allowed per program {loc_suffix(t)}",
                    t,
                )
            advance()  # consume 'search'
            namespaces = []

            def validate_namespace(token):
                ns = token["lexeme"]
                if not _is_valid_namespace(ns):
                    raise parser_error(
                        "P004",
                        f"Invalid namespace '{ns}' {loc_suffix(token)}. Valid namespaces: {', '.join(VALID_NAMESPACES)}",
                        token,
                    )

            first_token = peek()
            if first_token["type"] not in namespace_token_types:
                raise parser_error(
                    "P004",
                    f"Expected namespace identifier after search {loc_suffix(first_token)}",
                    first_token,
                )
            advance()
            validate_namespace(first_token)
            namespaces.append(first_token["lexeme"])
            while peek()["type"] == "COMMA":
                advance()  # consume ','
                ns_token = peek()
                if ns_token["type"] not in namespace_token_types:
                    raise parser_error(
                        "P004",
                        f"Expected namespace identifier after comma {loc_suffix(ns_token)}",
                        ns_token,
                    )
                advance()
                validate_namespace(ns_token)
                namespaces.append(ns_token["lexeme"])
            program_search_order["value"] = namespaces
            program_namespace["imports"] = [
                {"name": name, "source": "search", "explicit": True} for name in namespaces
            ]
            program_namespace["default"] = {
                "name": namespaces[0], "source": "search", "explicit": True
            }
            while peek()["type"] == "SEMICOLON":
                advance()

        while peek()["type"] != "EOF":
            if peek()["type"] == "SEMICOLON":
                advance()
                continue
            leading_comments = collect_comments()
            if peek()["type"] == "EOF":
                if len(leading_comments) > 0:
                    trailing_comments.extend(leading_comments)
                break
            if peek()["type"] == "SEMICOLON":
                continue
            if peek()["type"] == "SEARCH":
                if len(plans) or len(variables) or render["value"]:
                    t = peek()
                    raise parser_error(
                        "P004",
                        f"'search' directive must appear before other statements {loc_suffix(t)}",
                        t,
                    )
                parse_search_directive()
                continue
            if peek()["type"] == "RENDER":
                consume_render()
                if len(leading_comments) > 0 and render["value"]:
                    render["value"]["leadingComments"] = leading_comments
                trailing = collect_comments()
                if len(trailing) > 0:
                    trailing_comments.extend(trailing)
                break
            stmt = parse_statement()
            if len(leading_comments) > 0 and stmt:
                stmt["leadingComments"] = leading_comments
            append_statement(stmt)
            while peek()["type"] == "SEMICOLON":
                advance()

        eof = expect("EOF", "Expected end of input")
        if not program_search_order["value"] or len(program_search_order["value"]) == 0:
            raise parser_error(
                "P004",
                "Missing required 'search' directive. Every program must start with "
                "'search <namespace>, ...' to specify namespace search order.",
                eof,
            )

        program = {"type": "Program", "plans": plans, "render": render["value"]}
        if len(variables):
            program["vars"] = variables
        if len(trailing_comments):
            program["trailingComments"] = trailing_comments

        search_order = list(program_search_order["value"])
        imports_clone = [dict(entry) for entry in program_namespace["imports"]]
        default_clone = (
            dict(program_namespace["default"]) if program_namespace["default"] else None
        )
        program["namespace"] = {
            "imports": imports_clone,
            "default": default_clone,
            "searchOrder": list(search_order),
        }
        return program

    def parse_block():
        expect("LBRACE", "Expect '{'")
        body = []
        while peek()["type"] != "RBRACE":
            stmt = parse_statement()
            body.append(stmt)
            while peek()["type"] == "SEMICOLON":
                advance()
        expect("RBRACE", "Expect '}'")
        return body

    def parse_statement():
        if peek()["type"] == "SEARCH":
            t = peek()
            raise parser_error(
                "P004",
                f"'search' directive is only allowed at the start of the program {loc_suffix(t)}",
                t,
            )
        if peek()["type"] == "LET":
            advance()
            name = expect("IDENT", "Expected identifier")["lexeme"]
            expect("EQUAL", "Expect '='")
            if peek()["type"] not in expr_start_tokens:
                t = peek()
                raise parser_error(
                    "P001",
                    f"Expected expression after '=' {loc_suffix(t)}",
                    t,
                )
            expr = parse_additive()
            return {"type": "VarAssign", "name": name, "expr": expr}

        tt = peek()["type"]
        if tt == "IF":
            advance()
            expect("LPAREN", "Expect '('")
            condition = parse_additive()
            expect("RPAREN", "Expect ')'")
            then = parse_block()
            elif_branches = []
            while peek()["type"] == "ELIF":
                advance()
                expect("LPAREN", "Expect '('")
                ec = parse_additive()
                expect("RPAREN", "Expect ')'")
                body = parse_block()
                elif_branches.append({"condition": ec, "then": body})
            else_branch = None
            if peek()["type"] == "ELSE":
                advance()
                else_branch = parse_block()
            return {
                "type": "IfStmt",
                "condition": condition,
                "then": then,
                "elif": elif_branches,
                "else": else_branch,
            }
        if tt == "BREAK":
            advance()
            return {"type": "Break"}
        if tt == "CONTINUE":
            advance()
            return {"type": "Continue"}
        if tt == "RETURN":
            advance()
            if peek()["type"] in expr_start_tokens:
                value = parse_additive()
                return {"type": "Return", "value": value}
            return {"type": "Return"}

        chain = parse_chain()
        # Extract write/write3d only if the chain TERMINATES with a Write/Write3D node.
        write = None
        write3d = None
        if len(chain) > 0:
            last_node = chain[len(chain) - 1]
            if last_node.get("type") == "Write":
                write = last_node["surface"]
            elif last_node.get("type") == "Write3D":
                write3d = {"tex3d": last_node["tex3d"], "geo": last_node["geo"]}

        return {"chain": chain, "write": write, "write3d": write3d}

    def parse_chain(context="statement"):
        first_call = parse_call()
        calls = [first_call]
        while True:
            saved_pos = state["current"]
            leading_comments = collect_comments()
            if peek()["type"] != "DOT":
                state["current"] = saved_pos
                break
            advance()  # consume '.'
            post_dot_comments = collect_comments()
            all_comments = list(leading_comments) + list(post_dot_comments)

            next_type = peek()["type"]
            if next_type == "WRITE" or next_type == "WRITE3D":
                if context == "expression":
                    t = peek()
                    raise parser_error(
                        "P005",
                        f"'.write()' is only allowed in statement context {loc_suffix(t)}",
                        t,
                    )
                write_node = parse_write_call()
                if len(all_comments) > 0:
                    write_node["leadingComments"] = all_comments
                calls.append(write_node)
                continue
            if next_type == "SUBCHAIN":
                subchain_node = parse_subchain_call()
                if len(all_comments) > 0:
                    subchain_node["leadingComments"] = all_comments
                calls.append(subchain_node)
                continue
            call = parse_call()
            if len(all_comments) > 0:
                call["leadingComments"] = all_comments
            calls.append(call)
        return calls

    def parse_write_call():
        tok = peek()
        token_type = tok.get("type") if isinstance(tok, dict) else None
        token_line = tok.get("line") if isinstance(tok, dict) else None
        token_col = tok.get("col") if isinstance(tok, dict) else None
        if token_col is None and isinstance(tok, dict):
            token_col = tok.get("column")

        if token_type == "WRITE":
            advance()  # consume 'write'
            expect("LPAREN", "Expect '('")
            surface = None
            p = peek()
            if p["type"] == "OUTPUT_REF":
                surface = {"type": "OutputRef", "name": advance()["lexeme"]}
            elif p["type"] == "XYZ_REF":
                surface = {"type": "XyzRef", "name": advance()["lexeme"]}
            elif p["type"] == "VEL_REF":
                surface = {"type": "VelRef", "name": advance()["lexeme"]}
            elif p["type"] == "RGBA_REF":
                surface = {"type": "RgbaRef", "name": advance()["lexeme"]}
            elif p["type"] == "MESH_REF":
                surface = {"type": "MeshRef", "name": advance()["lexeme"]}
            elif p["type"] == "IDENT" and p["lexeme"] == "none":
                surface = {"type": "OutputRef", "name": advance()["lexeme"]}
            else:
                raise parser_error(
                    "P005",
                    f"write() requires an explicit surface reference (e.g., o0, o1, xyz0, vel0, rgba0, mesh0, none) {loc_suffix(peek())}",
                    peek(),
                )
            expect("RPAREN", "Expect ')'")
            return {
                "type": "Write",
                "surface": surface,
                "loc": {"line": token_line, "col": token_col},
            }
        elif token_type == "WRITE3D":
            advance()  # consume 'write3d'
            expect("LPAREN", "Expect '('")
            tex3d = None
            p = peek()
            if p["type"] in ("IDENT", "OUTPUT_REF", "VOL_REF"):
                tok_type = p["type"]
                if tok_type == "OUTPUT_REF":
                    tex3d = {"type": "OutputRef", "name": advance()["lexeme"]}
                elif tok_type == "VOL_REF":
                    tex3d = {"type": "VolRef", "name": advance()["lexeme"]}
                else:
                    tex3d = {"type": "Ident", "name": advance()["lexeme"]}
            else:
                raise parser_error(
                    "P005",
                    f"Expected tex3d reference in write3d() {loc_suffix(peek())}",
                    peek(),
                )
            expect("COMMA", "Expect ',' between tex3d and geo in write3d()")
            geo = None
            p = peek()
            if p["type"] in ("IDENT", "OUTPUT_REF", "GEO_REF"):
                tok_type = p["type"]
                if tok_type == "OUTPUT_REF":
                    geo = {"type": "OutputRef", "name": advance()["lexeme"]}
                elif tok_type == "GEO_REF":
                    geo = {"type": "GeoRef", "name": advance()["lexeme"]}
                else:
                    geo = {"type": "Ident", "name": advance()["lexeme"]}
            else:
                raise parser_error(
                    "P005",
                    f"Expected geo reference in write3d() {loc_suffix(peek())}",
                    peek(),
                )
            expect("RPAREN", "Expect ')'")
            return {
                "type": "Write3D",
                "tex3d": tex3d,
                "geo": geo,
                "loc": {"line": token_line, "col": token_col},
            }
        loc_tok = {"line": token_line, "col": token_col}
        raise parser_error(
            "P005",
            f"Expected write or write3d {loc_suffix(loc_tok)}",
            loc_tok,
        )

    def parse_subchain_call():
        tok = peek()

        advance()  # consume 'subchain'
        expect("LPAREN", "Expect '(' after subchain")

        kwargs = {}
        subchain_keys = ("name", "id")
        subchain_argument_diagnostics = []

        def report_arg_issue(code, message, token):
            if options and options.get("subchainArguments") == "strict":
                raise parser_error(code, message, token, severity_override="error")
            err = parser_error(code, message, token)
            subchain_argument_diagnostics.append(err.diagnostic)

        if peek()["type"] != "RPAREN":
            if peek()["type"] == "STRING":
                kwargs["name"] = {"type": "String", "value": advance()["lexeme"]}
            elif peek()["type"] == "IDENT" and (
                tok_at(state["current"] + 1) is not None
                and tok_at(state["current"] + 1).get("type") == "COLON"
            ):
                while peek()["type"] == "IDENT" and (
                    tok_at(state["current"] + 1) is not None
                    and tok_at(state["current"] + 1).get("type") == "COLON"
                ):
                    key_token = advance()
                    key = key_token["lexeme"]
                    advance()  # consume ':'
                    if peek()["type"] != "STRING":
                        raise parser_error(
                            "P006",
                            f"Expected string value for subchain {key} {loc_suffix(peek())}",
                            peek(),
                        )
                    val = advance()["lexeme"]
                    if key not in subchain_keys:
                        report_arg_issue(
                            "P008",
                            f"Unknown subchain argument '{key}' {loc_suffix(key_token)}. Valid keys: name, id. The value is discarded.",
                            key_token,
                        )
                    elif key in kwargs:
                        report_arg_issue(
                            "P009",
                            f"Duplicate subchain argument '{key}' {loc_suffix(key_token)}. The last value wins.",
                            key_token,
                        )
                    kwargs[key] = {"type": "String", "value": val}
                    if peek()["type"] == "COMMA":
                        advance()  # consume ','
                    elif peek()["type"] == "IDENT" and (
                        tok_at(state["current"] + 1) is not None
                        and tok_at(state["current"] + 1).get("type") == "COLON"
                    ):
                        report_arg_issue(
                            "P010",
                            f"Missing ',' between subchain arguments {loc_suffix(peek())}",
                            peek(),
                        )
        expect("RPAREN", "Expect ')' after subchain arguments")

        expect("LBRACE", "Expect '{' to start subchain body")

        body = []
        while peek()["type"] != "RBRACE":
            leading_comments = collect_comments()
            if peek()["type"] == "RBRACE":
                break
            if peek()["type"] != "DOT":
                raise parser_error(
                    "P006",
                    f"Expected '.' before chain element in subchain body {loc_suffix(peek())}",
                    peek(),
                )
            advance()  # consume '.'
            post_dot_comments = collect_comments()
            all_comments = list(leading_comments) + list(post_dot_comments)
            call = parse_call()
            if len(all_comments) > 0:
                call["leadingComments"] = all_comments
            body.append(call)

        expect("RBRACE", "Expect '}' to end subchain body")

        if len(body) == 0:
            raise parser_error(
                "P006",
                f"Subchain body cannot be empty {loc_suffix(tok)}",
                tok,
            )

        name_node = kwargs.get("name")
        id_node = kwargs.get("id")
        base_node = {
            "type": "Subchain",
            "name": (name_node["value"] if name_node else None),
            "id": (id_node["value"] if id_node else None),
            "body": body,
            "loc": tok_loc(tok),
        }
        if len(subchain_argument_diagnostics) > 0:
            node = AstNode(base_node)
            node.subchainArgumentDiagnostics = subchain_argument_diagnostics
            return node
        return base_node

    def parse_call():
        name_token = expect("IDENT", "Expected identifier")
        # Inline namespace syntax (e.g., nd.noise()) is forbidden.
        if peek()["type"] == "DOT":
            nxt = tok_at(state["current"] + 1)
            if nxt and nxt.get("type") == "IDENT":
                after = tok_at(state["current"] + 2)
                if after is not None and after.get("type") == "LPAREN":
                    raise parser_error(
                        "P007",
                        f"Inline namespace syntax '{name_token.get('lexeme')}.{nxt.get('lexeme')}()' is not allowed. "
                        f"Use 'search {name_token.get('lexeme')}' at the start of the program instead, "
                        f"{loc_suffix(name_token)}",
                        name_token,
                    )
        expect("LPAREN", "Expect '('")
        args = []
        kwargs = {}
        keyword = False
        positional = False
        allow_mixed = name_token["lexeme"] in ("midi", "audio")
        if peek()["type"] != "RPAREN":
            while True:
                nxt = tok_at(state["current"] + 1)
                if peek()["type"] == "IDENT" and nxt is not None and nxt.get("type") == "COLON":
                    if positional and not allow_mixed:
                        t = peek()
                        raise parser_error(
                            "P007",
                            f"Cannot mix positional and keyword arguments {loc_suffix(t)}",
                            t,
                        )
                    keyword = True
                    parse_kwarg(kwargs)
                else:
                    if keyword and not allow_mixed:
                        t = peek()
                        raise parser_error(
                            "P007",
                            f"Cannot mix positional and keyword arguments {loc_suffix(t)}",
                            t,
                        )
                    positional = True
                    args.append(parse_arg())
                if peek()["type"] != "COMMA":
                    break
                advance()
                if peek()["type"] == "RPAREN":
                    break
        expect("RPAREN", "Expect ')'")
        call = {"type": "Call", "name": name_token["lexeme"], "args": args}
        if keyword:
            call["kwargs"] = kwargs
        name = name_token["lexeme"]
        if name == "from":
            return transform_from_invocation(call, name_token)
        # osc() as a value oscillator (not the synth.osc generator effect).
        if name == "osc":
            osc_kwargs = frozenset(["type", "min", "max", "speed", "offset", "seed"])
            has_type_kwarg = bool(kwargs) and ("type" in kwargs)
            first_arg_is_osc_kind = (
                len(args) > 0
                and args[0]
                and args[0].get("type") == "Member"
                and args[0].get("path")
                and args[0]["path"][0] == "oscKind"
            )
            is_bare_osc = len(args) == 0 and (not kwargs or len(kwargs) == 0)
            has_only_osc_kwargs = (
                bool(kwargs)
                and len(kwargs) > 0
                and all(k in osc_kwargs for k in kwargs.keys())
            )
            if has_type_kwarg or first_arg_is_osc_kind or is_bare_osc or has_only_osc_kwargs:
                return transform_osc_invocation(call, name_token)
            # Fall through to return as regular Call node for synth effect.
        if name == "midi":
            return transform_midi_invocation(call, name_token)
        if name == "audio":
            return transform_audio_invocation(call, name_token)
        # read() is a pipeline built-in for reading 2D surfaces.
        if name == "read":
            surface = None
            if len(args) > 0:
                surface = args[0]
            elif "tex" in kwargs:
                surface = kwargs["tex"]
            elif "surface" in kwargs:
                surface = kwargs["surface"]
            node = {
                "type": "Read",
                "surface": surface,
                "loc": tok_loc(name_token),
            }
            skip = kwargs.get("_skip")
            if skip and skip.get("type") == "Boolean" and skip.get("value") is True:
                node["_skip"] = True
            return node
        # read3d() reads from tex3d (and optionally geo) surfaces.
        if name == "read3d":
            tex3d = args[0] if len(args) > 0 else kwargs.get("tex3d")
            geo = args[1] if len(args) > 1 else kwargs.get("geo")
            node = {
                "type": "Read3D",
                "tex3d": tex3d,
                "geo": geo if geo else None,
                "loc": tok_loc(name_token),
            }
            skip = kwargs.get("_skip")
            if skip and skip.get("type") == "Boolean" and skip.get("value") is True:
                node["_skip"] = True
            return node
        return call

    def parse_arg():
        return parse_additive()

    def parse_additive():
        node = parse_multiplicative()
        while peek()["type"] == "PLUS" or peek()["type"] == "MINUS":
            op = advance()["type"]
            right = parse_multiplicative()
            left_val = to_number(node)
            right_val = to_number(right)
            node = {
                "type": "Number",
                "value": _js_binary_number(left_val, right_val, op),
            }
        return node

    def parse_multiplicative():
        node = parse_unary()
        while peek()["type"] == "STAR" or peek()["type"] == "SLASH":
            op = advance()["type"]
            right = parse_unary()
            left_val = to_number(node)
            right_val = to_number(right)
            node = {
                "type": "Number",
                "value": _js_binary_number(left_val, right_val, op),
            }
        return node

    def parse_unary():
        if peek()["type"] == "PLUS":
            advance()
            return parse_unary()
        if peek()["type"] == "MINUS":
            advance()
            val = parse_unary()
            return {
                "type": "Number",
                "value": _make_number(-_to_js_number(to_number(val))),
            }
        return parse_primary()

    def parse_primary():
        token = peek()
        tt = token["type"]
        if tt == "NUMBER":
            advance()
            return {"type": "Number", "value": _parse_js_number(token["lexeme"])}
        if tt == "STRING":
            advance()
            return {"type": "String", "value": token["lexeme"]}
        if tt == "HEX":
            advance()
            hex_str = token["lexeme"][1:]
            a = 1.0
            if len(hex_str) == 3:
                r = int(hex_str[0] + hex_str[0], 16)
                g = int(hex_str[1] + hex_str[1], 16)
                b = int(hex_str[2] + hex_str[2], 16)
            elif len(hex_str) == 6:
                r = int(hex_str[0:2], 16)
                g = int(hex_str[2:4], 16)
                b = int(hex_str[4:6], 16)
            elif len(hex_str) == 8:
                r = int(hex_str[0:2], 16)
                g = int(hex_str[2:4], 16)
                b = int(hex_str[4:6], 16)
                a = int(hex_str[6:8], 16) / 255
            else:
                # Lexer only emits HEX for lengths 3/6/8, so this is unreachable; mirror JS
                # (where r/g/b would be undefined) defensively by raising.
                raise SyntaxError_(
                    f"Invalid hex color {loc_suffix(token)}"
                )
            return {
                "type": "Color",
                "value": [
                    _make_number(r / 255),
                    _make_number(g / 255),
                    _make_number(b / 255),
                    _make_number(a),
                ],
            }
        if tt == "LBRACKET":
            loc = tok_loc(token)
            bracket_pos = getattr(token, "position", None) or (token.get("position") if isinstance(token, dict) else None)
            advance()
            elements = []
            if peek()["type"] != "RBRACKET":
                elements.append(parse_arg())
                while peek()["type"] == "COMMA":
                    advance()
                    elements.append(parse_arg())
            if peek()["type"] != "RBRACKET":
                t = peek()
                raise parser_error(
                    "P001",
                    f"Expected ']' {loc_suffix(t)}",
                    t,
                )
            advance()
            base_node = {
                "type": "ArrayLiteral",
                "elements": elements,
                "loc": loc,
            }
            if bracket_pos:
                array_node = AstNode(base_node)
                array_node.position = bracket_pos
                return array_node
            return base_node
        if tt == "FUNC":
            advance()
            return {"type": "Func", "src": token["lexeme"]}
        if tt == "TRUE":
            advance()
            return {"type": "Boolean", "value": True}
        if tt == "FALSE":
            advance()
            return {"type": "Boolean", "value": False}
        if tt == "IDENT":
            t1 = tok_at(state["current"] + 1)
            t2 = tok_at(state["current"] + 2)
            if (
                token["lexeme"] == "Math"
                and t1 is not None and t1.get("type") == "DOT"
                and t2 is not None and t2.get("type") == "IDENT" and t2.get("lexeme") == "PI"
            ):
                advance()
                advance()
                advance()
                return {"type": "Number", "value": _make_number(math.pi)}
            if (t1 is not None and t1.get("type") == "LPAREN") or has_call_after_dot(
                state["current"]
            ):
                chain = parse_chain("expression")
                if len(chain) == 1:
                    return chain[0]
                return {"type": "Chain", "chain": chain}
            advance()
            path = [token["lexeme"]]
            while peek()["type"] == "DOT":
                nxt = tok_at(state["current"] + 1)
                if nxt is None:
                    break
                after = tok_at(state["current"] + 2)
                if after is not None and after.get("type") == "LPAREN":
                    break
                if nxt.get("type") not in member_token_types:
                    raise parser_error(
                        "P001",
                        f"Expected identifier after '.' {loc_suffix(nxt)}",
                        nxt,
                    )
                advance()  # consume '.'
                advance()  # consume segment token (nxt)
                path.append(nxt["lexeme"])
            if len(path) > 1:
                return {"type": "Member", "path": path}
            return {"type": "Ident", "name": path[0]}
        if tt == "OUTPUT_REF":
            advance()
            return {"type": "OutputRef", "name": token["lexeme"]}
        if tt == "SOURCE_REF":
            advance()
            return {"type": "SourceRef", "name": token["lexeme"]}
        if tt == "VOL_REF":
            advance()
            return {"type": "VolRef", "name": token["lexeme"]}
        if tt == "GEO_REF":
            advance()
            return {"type": "GeoRef", "name": token["lexeme"]}
        if tt == "XYZ_REF":
            advance()
            return {"type": "XyzRef", "name": token["lexeme"]}
        if tt == "VEL_REF":
            advance()
            return {"type": "VelRef", "name": token["lexeme"]}
        if tt == "RGBA_REF":
            advance()
            return {"type": "RgbaRef", "name": token["lexeme"]}
        if tt == "MESH_REF":
            advance()
            return {"type": "MeshRef", "name": token["lexeme"]}
        if tt == "LPAREN":
            advance()
            expr = parse_additive()
            expect("RPAREN", "Expect ')'")
            return expr
        raise parser_error(
            "P001",
            f"Unexpected token {tt} {loc_suffix(token)}",
            token,
        )

    def to_number(node):
        if not isinstance(node, dict) or node.get("type") != "Number":
            loc = node.get("loc") if isinstance(node, dict) and isinstance(node.get("loc"), dict) else {}
            token_like = {
                "position": getattr(node, "position", None) or (node.get("position") if isinstance(node, dict) else None),
                "line": loc.get("line"),
                "col": loc.get("col"),
            }
            raise parser_error("P001", "Expected number", token_like)
        return node["value"]

    def parse_kwarg(obj):
        key = expect("IDENT", "Expected identifier")["lexeme"]
        expect("COLON", "Expect ':'")
        if peek()["type"] not in expr_start_tokens:
            t = peek()
            raise parser_error(
                "P001",
                f"Expected expression after '=' {loc_suffix(t)}",
                t,
            )
        obj[key] = parse_arg()

    return parse_program()


def parse_source(src, options=None):
    """Convenience: lex ``src`` with the stage-1 lexer, then parse. Returns the Program AST."""
    return parse(lex(src), options=options)
