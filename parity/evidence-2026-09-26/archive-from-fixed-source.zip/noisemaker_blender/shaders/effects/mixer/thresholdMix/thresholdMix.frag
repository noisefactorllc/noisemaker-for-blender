#define nmTex(s, uv) (texelFetch((s), clamp(ivec2(floor((uv)*vec2(textureSize((s),0)))), ivec2(0), textureSize((s),0)-ivec2(1)), 0))
/*
 * ThresholdMix mixer shader
 * Combines two input textures using threshold masking with optional posterization
 * Supports luminance-based or per-channel RGB thresholding
 */

// Convert RGB to luminosity
float getLuminosity(vec3 color) {
    return dot(color, vec3(0.299, 0.587, 0.114));
}

// Quantize a value into discrete bands
float quantizeValue(float value, int bands) {
    if (bands <= 0) return value;
    float numBands = float(bands);
    return floor(value * numBands) / numBands;
}

// Calculate blend factor with threshold and range
// Returns 0 for values below threshold, 1 for values above threshold+range
// Smooth transition in between
float calculateBlendFactor(float mapValue, float thresh, float rng) {
    if (rng <= 0.0) {
        // Hard threshold
        return step(thresh, mapValue);
    } else {
        // Soft threshold with range
        float lower = thresh;
        float upper = thresh + rng;
        return smoothstep(lower, upper, mapValue);
    }
}

void main() {
    vec2 globalCoord = gl_FragCoord.xy + tileOffset;
    vec2 uv = globalCoord / fullResolution;
    
    vec4 colorA = nmTex(inputTex, gl_FragCoord.xy / vec2(textureSize(inputTex, 0)));
    vec4 colorB = nmTex(tex, gl_FragCoord.xy / vec2(textureSize(tex, 0)));
    
    // Get map color based on mapSource
    vec3 mapColor;
    if (mapSource == 0) {
        mapColor = colorA.rgb;
    } else {
        mapColor = colorB.rgb;
    }
    
    // Apply quantization to map values if enabled
    if (quantize > 0) {
        mapColor.r = quantizeValue(mapColor.r, quantize);
        mapColor.g = quantizeValue(mapColor.g, quantize);
        mapColor.b = quantizeValue(mapColor.b, quantize);
    }
    
    vec4 result;
    
    if (mode == 0) {
        // Luminance mode - use single threshold for all channels
        float lum = getLuminosity(mapColor);
        float blendFactor = calculateBlendFactor(lum, threshold, range);
        result = mix(colorA, colorB, blendFactor);
    } else {
        // RGB mode - use separate threshold for each channel
        float blendR = calculateBlendFactor(mapColor.r, thresholdR, rangeR);
        float blendG = calculateBlendFactor(mapColor.g, thresholdG, rangeG);
        float blendB = calculateBlendFactor(mapColor.b, thresholdB, rangeB);
        
        result.r = mix(colorA.r, colorB.r, blendR);
        result.g = mix(colorA.g, colorB.g, blendG);
        result.b = mix(colorA.b, colorB.b, blendB);
        result.a = mix(colorA.a, colorB.a, (blendR + blendG + blendB) / 3.0);
    }
    
    fragColor = result;
}
