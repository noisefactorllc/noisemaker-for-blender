#define nmTex(s, uv) (texelFetch((s), clamp(ivec2(floor((uv)*vec2(textureSize((s),0)))), ivec2(0), textureSize((s),0)-ivec2(1)), 0))
// Standard uniforms

// Physics parameters

// Input state from pipeline (from pointsEmit)

// Output state (MRT)

// Integer-based hash for cross-platform determinism
uint hash_uint(uint seed) {
    uint state = seed * 747796405u + 2891336453u;
    uint word = ((state >> ((state >> 28u) + 4u)) ^ state) * 277803737u;
    return (word >> 22u) ^ word;
}

float hash(uint seed) {
    return float(hash_uint(seed)) / 4294967295.0;
}

// Smooth noise for wander perturbation
float noise2D(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);  // Smoothstep
    
    uint n = uint(i.x) + uint(i.y) * 57u;
    float a = hash(n);
    float b = hash(n + 1u);
    float c = hash(n + 57u);
    float d = hash(n + 58u);
    
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

// Fractal noise for smoother motion
float fbm(vec2 p) {
    float v = 0.0;
    float a = 0.5;
    for (int i = 0; i < 3; i++) {
        v += a * noise2D(p);
        p *= 2.0;
        a *= 0.5;
    }
    return v;
}

void main() {
    ivec2 coord = ivec2(gl_FragCoord.xy);
    ivec2 stateSize = textureSize(xyzTex, 0);
    
    // Read input state from pipeline
    vec4 xyz = texelFetch(xyzTex, coord, 0);
    vec4 vel = texelFetch(velTex, coord, 0);
    vec4 rgba = texelFetch(rgbaTex, coord, 0);
    
    // Extract components
    float px = xyz.x;  // Position in normalized coords [0,1]
    float py = xyz.y;
    float pz = xyz.z;
    float alive = xyz.w;
    
    float vx = vel.x;
    float vy = vel.y;
    float vz = vel.z;
    float seed_f = vel.w;
    
    // If not alive, pass through unchanged
    if (alive < 0.5) {
        outXYZ = xyz;
        outVel = vel;
        outRGBA = rgba;
        return;
    }
    
    // Per-particle deviation (0 = all same speed, 1 = highly varied)
    float deviationMultiplier = 1.0 + (seed_f - 0.5) * deviation * 2.0;
    
    // Smooth wander perturbation using noise field
    float noiseScale = 2.0;  // Adjust for normalized coords
    float wanderAngle = fbm(vec2(px, py) * noiseScale + time * 0.5) * 6.283185 * 2.0;
    float wanderStrength = wander * 0.002;  // Scaled for normalized coords
    float wanderX = cos(wanderAngle) * wanderStrength;
    float wanderY = sin(wanderAngle) * wanderStrength;
    
    // Physics forces (scaled for normalized coords)
    // Use energy as a global multiplier for visible movement
    float ax = (wind * 0.01 + wanderX) * energy;
    float ay = (-gravity * 0.01 + wanderY) * energy;  // Negate: positive gravity pulls down
    
    // Update velocity with deviation
    vx += ax * deviationMultiplier;
    vy += ay * deviationMultiplier;
    
    // Apply drag coefficient (0 = no drag, 0.2 = heavy drag)
    float dragFactor = 1.0 - drag;
    vx *= dragFactor;
    vy *= dragFactor;
    
    // Update position (deviation already factored into velocity)
    px += vx;
    py += vy;
    
    // Check for respawn conditions - set alive=0 to signal respawn
    bool needsRespawn = false;
    
    // Respawn if out of bounds (normalized coords)
    if (px < 0.0 || px > 1.0 || py < 0.0 || py > 1.0) {
        needsRespawn = true;
    }
    
    // Attrition is now handled by pointsEmit
    
    if (needsRespawn) {
        // Signal respawn by setting alive flag to 0
        // pointsEmit will handle actual respawn on next frame
        outXYZ = vec4(px, py, pz, 0.0);
        outVel = vec4(vx, vy, vz, seed_f);
        outRGBA = rgba;
    } else {
        outXYZ = vec4(px, py, pz, 1.0);
        outVel = vec4(vx, vy, vz, seed_f);
        outRGBA = rgba;
    }
}
