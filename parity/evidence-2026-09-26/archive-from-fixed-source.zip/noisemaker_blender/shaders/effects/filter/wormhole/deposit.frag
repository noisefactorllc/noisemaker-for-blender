void main() {
    fragColor = vColor;
}
