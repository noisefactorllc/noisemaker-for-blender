#define nmTex(s, uv) (texelFetch((s), clamp(ivec2(floor((uv)*vec2(textureSize((s),0)))), ivec2(0), textureSize((s),0)-ivec2(1)), 0))
// Preview mesh data as a visualization
// Renders positions/normals as colors for debugging

void main() {
    vec2 globalCoord = gl_FragCoord.xy + tileOffset;
    vec2 fullRes = fullResolution.x > 0.0 ? fullResolution : resolution;
    // Global UV for image-space layout decisions (left/right half split)
    vec2 globalUV = (gl_FragCoord.xy + tileOffset) / fullRes;
    // Tile-local UV for sampling the mesh textures
    vec2 uv = globalCoord / fullResolution;

    // Sample mesh data using nmTex() for proper UV sampling
    // The mesh textures are smaller than output, so use UV coordinates
    vec4 pos = nmTex(positionsTex, gl_FragCoord.xy / vec2(textureSize(positionsTex, 0)));
    vec4 normal = nmTex(normalsTex, gl_FragCoord.xy / vec2(textureSize(normalsTex, 0)));

    // Visualize: left half shows positions, right half shows normals
    vec3 color;
    if (globalUV.x < 0.5) {
        // Position visualization: map -1..1 to 0..1
        color = pos.xyz * 0.5 + 0.5;
    } else {
        // Normal visualization: map -1..1 to 0..1
        color = normal.xyz * 0.5 + 0.5;
    }
    
    // Check if this is a valid nm_vertex (w > 0 in position means valid nm_vertex ID)
    float alpha = 1.0;
    
    fragColor = vec4(color, alpha);
}
